# Implementation Plan - Fix "No Speech Detected" & Ensure Seamless Voice Typing

## User Review & Critical Decisions

> [!IMPORTANT]
> The following decisions have been confirmed:
> - **Primary Engine**: **Auto-Hybrid** (Uses online Gemini 2.5 Flash with prompt engineering for bilingual Bengali + English; automatically falls back to offline SpeechRecognizer if network or API quota is unavailable).
> - **Recording Stop Behavior**: **Keep microphone recording until the user's second tap on the [ 🎙️ MIC ] button** (no aggressive premature silence cut-offs).

---

## 1. Root Cause Analysis of "No speech detected"

1. **Premature Silence Timeout in Offline Speech Engine**:
   - In offline/SpeechRecognizer mode, Android's `SpeechRecognizer` frequently triggers `ERROR_SPEECH_TIMEOUT` or `ERROR_NO_MATCH` after 1-2 seconds of quiet or initial hesitation, terminating the session with "No speech detected" before the user finishes speaking.
   - Solution: In Auto-Hybrid mode, default to recording pure audio with `AudioRecorderManager` until the user explicitly taps the Mic button again. Do not prematurely abort.
2. **Audio Hardware Source & Level Sensitivity in `AudioRecord`**:
   - Certain devices and emulators require specific `AudioSource` channels (`MediaRecorder.AudioSource.MIC` or `DEFAULT`) and can yield low volume samples if gain is not properly applied.
   - If user taps Mic quickly or speaks softly, the PCM byte count or amplitude could trigger the empty check.
   - Solution: Lower minimum duration thresholds, add dynamic gain boost for low-amplitude speech, and ensure the audio thread flushes all recorded PCM chunks before sealing the WAV file.
3. **Gemini AI Transcription Prompt Sensitivity**:
   - The prompt previously instructed "If there is no speech, output nothing". When Gemini encountered faint speech or mixed background audio, it was returning empty string `""` which mapped to `EmptyResult ("No speech detected")`.
   - Solution: Update the Gemini prompt to be resilient and transcribe faint/soft words, Bengali accent variations, and mixed Bengali-English vocabulary without discarding the response.
4. **Auto-Hybrid Graceful Fallback**:
   - When Gemini returns empty or fails, instead of immediately giving up with a "No speech detected" error toast, automatically attempt on-device recognition fallback.

---

## 2. Changes to be Made

### A. `AudioRecorderManager.kt`
- Use high-compatibility audio source initialization: try `AudioSource.MIC`, then `AudioSource.DEFAULT`, then `AudioSource.VOICE_RECOGNITION`.
- Lower minimum audio threshold to 100ms so even brief words ("হ্যাঁ", "Hello", "OK") are preserved.
- Optimize `normalizePcm16Le` so quiet speech is amplified clearly to optimal recognition range (~24,000 peak).
- Ensure thread joins and flushes all audio buffers cleanly before writing the RIFF 44-byte WAV header.

### B. `GeminiTranscriber.kt`
- Refine `TRANSCRIPTION_PROMPT` to aggressively extract spoken Bengali (`বাংলা`) and English words without rejecting quiet or conversational utterances.
- Support both `gemini-2.5-flash` and graceful auto-retry.
- Filter out reasoning thoughts if any model part returns them.

### C. `FloatingBubbleService.kt`
- In `AUTO_HYBRID` mode:
  - 1st tap on `[ 🎙️ MIC ]`: Start recording audio via `AudioRecorderManager`. Display timer and pulsating red indicator. Microphone stays open continuously until the user taps again.
  - 2nd tap on `[ 🎙️ MIC ]`: Stop recording, normalize audio, send to `GeminiTranscriber`.
  - If Gemini fails (network/quota/404), trigger offline speech engine fallback smoothly.
  - Remove premature auto-cutoffs.
- Update `LocalSpeechEngine.kt`:
  - When in pure offline mode, prevent premature timeouts and preserve partial recognition buffers.

### D. Verification
- Verify build with `compile_applet`.
- Run unit/Robolectric test suite to ensure all transitions and state machines function correctly.
