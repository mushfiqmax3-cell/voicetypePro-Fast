package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class RacingTranscriberTest {

    private val flash = GeminiModel.FLASH_1_5.modelId
    private val v38 = GeminiModel.FLASH_3_8.modelId
    private val lite = GeminiModel.FLASH_LITE_3_5.modelId

    private fun entry(
        id: String,
        models: Set<String>,
        exhausted: Boolean = false
    ) = ApiKeyEntry(
        id = id,
        displayName = id,
        keyValue = "key-$id",
        isExhausted = exhausted,
        selectedModelIds = models
    )

    @Test
    fun skipsExhaustedKeys() {
        val result = RacingTranscriber.selectCombinations(
            listOf(entry("a", setOf(flash), exhausted = true), entry("b", setOf(flash)))
        )
        assertEquals(listOf(RacingTranscriber.Combination("key-b", flash)), result)
    }

    @Test
    fun allExhaustedFallsBackToEveryKey() {
        val result = RacingTranscriber.selectCombinations(
            listOf(entry("a", setOf(flash), true), entry("b", setOf(lite), true))
        )
        assertEquals(2, result.size)
    }

    @Test
    fun capsAtFiveAndInterleavesKeys() {
        val entries = listOf(
            entry("a", setOf(flash, v38, lite)),
            entry("b", setOf(flash, v38, lite))
        )
        val result = RacingTranscriber.selectCombinations(entries)
        assertEquals(5, result.size)
        // Both keys get their first model before any key gets a second one.
        assertEquals("key-a", result[0].keyValue)
        assertEquals("key-b", result[1].keyValue)
        assertEquals(flash, result[0].modelId)
        assertEquals(flash, result[1].modelId)
    }

    @Test
    fun rotationShiftsStartingKeyWhenOverLimit() {
        val entries = (1..6).map { entry("k$it", setOf(flash)) }
        val first = RacingTranscriber.selectCombinations(entries, startOffset = 0).map { it.keyValue }
        val shifted = RacingTranscriber.selectCombinations(entries, startOffset = 3).map { it.keyValue }
        assertEquals(5, first.size)
        assertEquals(5, shifted.size)
        assertTrue(first != shifted)
    }

    @Test
    fun emptyInputGivesEmptyList() {
        assertTrue(RacingTranscriber.selectCombinations(emptyList()).isEmpty())
    }

    @Test
    fun pickErrorPrefersEmptyResultThenServerProblems() {
        val e = RacingTranscriber.pickError(
            listOf(
                TranscriptionException.NoInternet(),
                TranscriptionException.QuotaExceeded(),
                TranscriptionException.EmptyResult()
            )
        )
        assertTrue(e is TranscriptionException.EmptyResult)

        val q = RacingTranscriber.pickError(
            listOf(TranscriptionException.NoInternet(), TranscriptionException.QuotaExceeded())
        )
        assertTrue(q is TranscriptionException.QuotaExceeded)
    }
}
