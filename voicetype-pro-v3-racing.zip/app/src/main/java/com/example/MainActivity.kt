package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.VoiceTypeProTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.init(this)
        enableEdgeToEdge()
        setContent {
            VoiceTypeProTheme {
                VoiceTypeMainScreen()
            }
        }
    }
}

data class PermissionChecklistState(
    val hasMicrophone: Boolean = false,
    val hasOverlay: Boolean = false,
    val hasAccessibility: Boolean = false,
    val hasNotifications: Boolean = false
) {
    val allGranted: Boolean
        get() = hasMicrophone && hasOverlay && hasAccessibility && hasNotifications
}

fun checkPermissionsState(context: Context): PermissionChecklistState {
    val micGranted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    val overlayGranted = Settings.canDrawOverlays(context)
    val accessibilityGranted = VoiceTypeAccessibilityService.isServiceEnabled(context)

    val notificationsGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.POST_NOTIFICATIONS
        ) == PackageManager.PERMISSION_GRANTED
    } else {
        true
    }

    return PermissionChecklistState(
        hasMicrophone = micGranted,
        hasOverlay = overlayGranted,
        hasAccessibility = accessibilityGranted,
        hasNotifications = notificationsGranted
    )
}

/**
 * Minimal main screen: a Settings icon (top-right) and one large central toggle that
 * starts / stops the floating mic. Missing permissions are requested one by one when the
 * toggle is tapped.
 */
@Composable
fun VoiceTypeMainScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var permissionState by remember { mutableStateOf(checkPermissionsState(context)) }
    val isServiceRunning by FloatingBubbleService.isRunningFlow.collectAsState()

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                permissionState = checkPermissionsState(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { permissionState = checkPermissionsState(context) }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { permissionState = checkPermissionsState(context) }

    fun onToggleClicked() {
        if (isServiceRunning) {
            FloatingBubbleService.stop(context)
            return
        }
        // Request whatever is missing, one step per tap.
        when {
            !permissionState.hasMicrophone -> {
                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }

            !permissionState.hasNotifications -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }

            !permissionState.hasOverlay -> {
                Toast.makeText(
                    context,
                    "Allow \"Display over other apps\" (অন্য অ্যাপের ওপর প্রদর্শন চালু করুন)",
                    Toast.LENGTH_LONG
                ).show()
                context.startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                )
            }

            !permissionState.hasAccessibility -> {
                Toast.makeText(
                    context,
                    "Turn ON \"VoiceType Pro Auto-Type\" (অ্যাক্সেসিবিলিটি সার্ভিস চালু করুন)",
                    Toast.LENGTH_LONG
                ).show()
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }

            Prefs.getApiKey(context).isBlank() -> {
                Toast.makeText(
                    context,
                    "Add your Gemini API key in Settings (সেটিংসে এপিআই কী দিন)",
                    Toast.LENGTH_LONG
                ).show()
                context.startActivity(Intent(context, SettingsActivity::class.java))
            }

            else -> FloatingBubbleService.start(context)
        }
    }

    val statusText = when {
        isServiceRunning -> "Floating mic is ON\nফ্লোটিং মাইক চালু আছে"
        !permissionState.hasMicrophone -> "Tap to allow Microphone\nমাইক্রোফোনের অনুমতি দিন"
        !permissionState.hasNotifications -> "Tap to allow Notifications\nনোটিফিকেশনের অনুমতি দিন"
        !permissionState.hasOverlay -> "Tap to allow Display over apps\nঅন্য অ্যাপের ওপর প্রদর্শনের অনুমতি দিন"
        !permissionState.hasAccessibility -> "Tap to enable Accessibility service\nঅ্যাক্সেসিবিলিটি সার্ভিস চালু করুন"
        else -> "Tap to start\nচালু করতে ট্যাপ করুন"
    }

    Scaffold(
        contentWindowInsets = WindowInsets.safeDrawing,
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Settings icon, top-right
            IconButton(
                onClick = { context.startActivity(Intent(context, SettingsActivity::class.java)) },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(8.dp)
                    .testTag("settings_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.Settings,
                    contentDescription = "Settings",
                    tint = MaterialTheme.colorScheme.onBackground
                )
            }

            // Large central toggle
            Column(
                modifier = Modifier
                    .align(Alignment.Center)
                    .fillMaxWidth()
                    .padding(horizontal = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(180.dp)
                        .clip(CircleShape)
                        .background(if (isServiceRunning) StatusRed else StatusGreen)
                        .clickable { onToggleClicked() }
                        .testTag("main_toggle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isServiceRunning) Icons.Filled.Stop else Icons.Filled.Mic,
                        contentDescription = if (isServiceRunning) "Stop" else "Start",
                        tint = Color.White,
                        modifier = Modifier.size(84.dp)
                    )
                }
                Spacer(modifier = Modifier.height(28.dp))
                Text(
                    text = statusText,
                    color = MaterialTheme.colorScheme.onBackground,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}
