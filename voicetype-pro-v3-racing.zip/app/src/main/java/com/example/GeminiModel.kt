package com.example

/**
 * Gemini models the user can enable per API key.
 * Add or remove entries here; the Settings screen and the repository pick them up automatically.
 */
enum class GeminiModel(
    val modelId: String,
    val displayName: String,
    val description: String
) {
    FLASH_1_5(
        modelId = "gemini-1.5-flash",
        displayName = "Gemini 1.5 Flash",
        description = "Default. Lowest latency (সবচেয়ে দ্রুত)"
    ),
    FLASH_3_8(
        modelId = "gemini-3.8-flash",
        displayName = "Gemini 3.8 Flash",
        description = "Newer Flash model, higher accuracy"
    ),
    FLASH_LITE_3_5(
        modelId = "gemini-3.5-flash-lite",
        displayName = "Gemini 3.5 Flash-Lite",
        description = "Lightweight fallback, best for quota saving"
    );

    companion object {
        val DEFAULT: GeminiModel = FLASH_1_5

        fun fromId(id: String?): GeminiModel? = entries.firstOrNull { it.modelId == id?.trim() }
    }
}
