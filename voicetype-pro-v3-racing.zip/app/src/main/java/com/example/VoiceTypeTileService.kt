package com.example

import android.app.PendingIntent
import android.content.Intent
import android.graphics.drawable.Icon
import android.os.Build
import android.provider.Settings
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Quick Settings tile that turns the floating bubble ([FloatingBubbleService]) ON / OFF.
 */
class VoiceTypeTileService : TileService() {

    private val scope = CoroutineScope(Dispatchers.Main.immediate)
    private var observeJob: Job? = null

    /** Tile became visible (panel pulled down): sync state and keep following the service. */
    override fun onStartListening() {
        super.onStartListening()
        updateTile(isBubbleServiceRunning())
        // Keeps the tile correct if the service is stopped from the notification / app while the panel is open.
        observeJob?.cancel()
        observeJob = scope.launch {
            FloatingBubbleService.isRunningFlow.collect { running -> updateTile(running) }
        }
    }

    override fun onStopListening() {
        observeJob?.cancel()
        observeJob = null
        super.onStopListening()
    }

    override fun onClick() {
        super.onClick()

        if (isBubbleServiceRunning()) {
            // ON -> OFF
            FloatingBubbleService.stop(this)   // = stopService(Intent(this, FloatingBubbleService::class.java))
            updateTile(false)
        } else {
            // OFF -> ON. The bubble needs the "Display over other apps" permission.
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
                openApp()
                return
            }
            FloatingBubbleService.start(this)  // startForegroundService() on API 26+, startService() below
            updateTile(true)
        }
    }

    /** True while FloatingBubbleService is alive (flag is set in its onCreate and cleared in onDestroy). */
    private fun isBubbleServiceRunning(): Boolean = FloatingBubbleService.isRunningFlow.value

    private fun updateTile(active: Boolean) {
        val tile = qsTile ?: return
        tile.state = if (active) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.icon = Icon.createWithResource(this, R.drawable.ic_mic_white)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.label = getString(R.string.tile_label)
            tile.subtitle = getString(if (active) R.string.tile_on else R.string.tile_off)
        } else {
            tile.label = getString(R.string.tile_label) + if (active) " • ON" else " • OFF"
        }
        tile.updateTile()
    }

    /** Opens the app (to grant permissions) and collapses the panel. */
    private fun openApp() {
        val intent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }
}
