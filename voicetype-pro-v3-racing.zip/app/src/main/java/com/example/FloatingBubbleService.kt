package com.example

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import androidx.core.content.ContextCompat
import android.graphics.PixelFormat
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.Locale
import kotlin.math.abs
import kotlin.math.hypot

/**
 * Foreground Service (foregroundServiceType="microphone") that displays the focus-preserving
 * floating bubble overlay on top of all applications and coordinates Gemini AI voice transcription,
 * direct text insertion, keyboard-synced visibility, swipe-to-cancel, and 30-second undo.
 */
class FloatingBubbleService : Service() {

    companion object {
        private const val NOTIFICATION_CHANNEL_ID = "voicetype_floating_mic_channel"
        private const val NOTIFICATION_ID = 4091
        private const val DRAG_THRESHOLD_PX = 10f
        private const val SWIPE_CANCEL_DP = 72
        private const val ANIM_MS = 220L
        private const val EXPAND_ANIM_MS = 200L
        private const val IDLE_PEEK_DELAY_MS = 3_500L
        private const val PEEK_HANDLE_DP = 22
        private const val PEEK_ALPHA = 0.5f
        private const val COLLAPSED_BUBBLE_DP = 56
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_FLOATING_SERVICE"

        private val _isRunningFlow = MutableStateFlow(false)
        val isRunningFlow: StateFlow<Boolean> = _isRunningFlow.asStateFlow()

        fun start(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingBubbleService::class.java)
            context.stopService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val stateMachine = BubbleStateMachine()

    private lateinit var windowManager: WindowManager
    private lateinit var layoutParams: WindowManager.LayoutParams
    private lateinit var audioRecorder: AudioRecorderManager

    private var overlayView: View? = null
    private var collapsedBubble: FrameLayout? = null
    private var expandedPill: LinearLayout? = null
    private var btnPillHandle: FrameLayout? = null
    private var btnMic: LinearLayout? = null
    private var imgMicState: ImageView? = null
    private var progressMic: ProgressBar? = null
    private var txtMicLabel: TextView? = null
    private var btnCross: FrameLayout? = null

    private var isExpanded = false
    private var timerJob: Job? = null
    private var transcriptionJob: Job? = null
    private var pulseAnimator: ObjectAnimator? = null
    private var elapsedSeconds = 0
    private var overlayAnimator: ValueAnimator? = null

    // Visibility / edge-peek state.
    private val mainHandler = Handler(Looper.getMainLooper())
    private val idleRunnable = Runnable { enterPeekMode() }
    private var keyboardOpen = false
    private var bubbleShown = false
    private var isPeeked = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.init(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        audioRecorder = AudioRecorderManager(
            context = this,
            onMaxDurationReached = {
                serviceScope.launch {
                    if (stateMachine.currentState == BubbleState.RECORDING) {
                        Toast.makeText(
                            this@FloatingBubbleService,
                            "Max 120s reached — transcribing…",
                            Toast.LENGTH_SHORT
                        ).show()
                        handleMicToggleTap()
                    }
                }
            }
        )
        startForegroundWithMicrophoneType()

        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(
                this,
                "Display over other apps permission is required.",
                Toast.LENGTH_LONG
            ).show()
            stopSelf()
            return
        }

        setupFloatingOverlay()
        _isRunningFlow.value = true

        serviceScope.launch {
            stateMachine.state.collect { state ->
                renderBubbleState(state)
                // Never hide mid-recording / transcription; apply a deferred hide once idle.
                syncBubbleVisibility()
                if (state == BubbleState.IDLE) restartIdleTimer() else cancelIdleTimer()
            }
        }

        // The bubble follows the soft keyboard: shown at the user's exact saved position while the
        // keyboard is open, hidden when it closes. Registering replays the current keyboard state.
        VoiceTypeAccessibilityService.onKeyboardStateChanged = { isOpen, _ ->
            serviceScope.launch { onKeyboardStateChanged(isOpen) }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startForegroundWithMicrophoneType() {
        createNotificationChannel()
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingBubbleService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStop = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_mic_white)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setContentIntent(pendingOpen)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                R.drawable.ic_close_white,
                getString(R.string.stop_floating_mic),
                pendingStop
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_text)
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    @SuppressLint("InflateParams", "ClickableViewAccessibility")
    private fun setupFloatingOverlay() {
        val inflater = LayoutInflater.from(this)
        val rootView = inflater.inflate(R.layout.floating_bubble, null)
        overlayView = rootView

        collapsedBubble = rootView.findViewById(R.id.collapsed_bubble)
        expandedPill = rootView.findViewById(R.id.expanded_pill)
        btnPillHandle = rootView.findViewById(R.id.btn_pill_handle)
        btnMic = rootView.findViewById(R.id.btn_mic)
        imgMicState = rootView.findViewById(R.id.img_mic_state)
        progressMic = rootView.findViewById(R.id.progress_mic)
        txtMicLabel = rootView.findViewById(R.id.txt_mic_label)
        btnCross = rootView.findViewById(R.id.btn_cross)

        // Position memory: spawn exactly where the user last dropped the bubble (clamped to the
        // current screen in case the resolution / orientation changed since).
        val (savedX, savedY) = savedPosition()

        // CRITICAL: FLAG_NOT_FOCUSABLE and FLAG_NOT_TOUCH_MODAL ensure the overlay NEVER steals
        // keyboard focus from the text field selected in another app. FLAG_LAYOUT_IN_SCREEN makes
        // layoutParams.y relative to the physical screen top, matching AccessibilityWindowInfo bounds.
        layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                // Lets the docked bubble sit partly off-screen (edge-peek) without being clamped.
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = savedX
            y = savedY
        }

        collapsedBubble?.setOnTouchListener(
            createDragOrTapTouchListener(swipeLeftCancelsRecording = true) {
                toggleExpandedPill()
            }
        )
        btnPillHandle?.setOnTouchListener(
            createDragOrTapTouchListener {
                toggleExpandedPill()
            }
        )

        btnMic?.setOnTouchListener(
            createDragOrTapTouchListener(swipeLeftCancelsRecording = true) {
                handleMicToggleTap()
            }
        )

        btnCross?.setOnClickListener {
            restartIdleTimer()
            handleCrossTap()
        }
        btnCross?.setOnLongClickListener {
            vibrateShort()
            Toast.makeText(this, "VoiceType Pro floating mic closed", Toast.LENGTH_SHORT).show()
            stopSelf()
            true
        }

        // Hidden until the keyboard opens (the accessibility callback replays its current state).
        rootView.visibility = View.GONE
        windowManager.addView(rootView, layoutParams)
    }

    /**
     * Drag / tap listener. When [swipeLeftCancelsRecording] is true and a recording is in progress,
     * a horizontal swipe to the left on this view cancels the recording instead of dragging the bubble.
     */
    private fun createDragOrTapTouchListener(
        swipeLeftCancelsRecording: Boolean = false,
        onTap: () -> Unit
    ): View.OnTouchListener {
        return object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDragging = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                val swipeMode = swipeLeftCancelsRecording &&
                    stateMachine.currentState == BubbleState.RECORDING
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        cancelIdleTimer() // any touch cancels the pending peek
                        if (!isPeeked) overlayAnimator?.cancel()
                        initialX = layoutParams.x
                        initialY = layoutParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDragging = false
                        return true
                    }

                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        if (!isDragging && hypot(dx, dy) > DRAG_THRESHOLD_PX) {
                            isDragging = true
                        }
                        // While recording, moves are treated as a possible swipe, not as a drag.
                        if (isDragging && !swipeMode && !isPeeked) {
                            val screenHeight = resources.displayMetrics.heightPixels
                            val maxY = (screenHeight - (overlayView?.height ?: 160)).coerceAtLeast(0)
                            // Absolute position from raw screen deltas: no accumulated rounding jitter.
                            val screenWidth = resources.displayMetrics.widthPixels
                            val maxX = (screenWidth - (overlayView?.width ?: dpToPx(COLLAPSED_BUBBLE_DP)))
                                .coerceAtLeast(0)
                            val newX = (initialX + dx.toInt()).coerceIn(0, maxX)
                            val newY = (initialY + dy.toInt()).coerceIn(48, maxY)
                            // Skip redundant layout passes when the position did not change.
                            if (newX != layoutParams.x || newY != layoutParams.y) {
                                layoutParams.x = newX
                                layoutParams.y = newY
                                updateOverlayViewLayout()
                            }
                        }
                        return true
                    }

                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                        val dx = event.rawX - initialTouchX
                        val dy = event.rawY - initialTouchY
                        val isLeftSwipe = event.actionMasked == MotionEvent.ACTION_UP &&
                            dx <= -dpToPx(SWIPE_CANCEL_DP) && abs(dx) > abs(dy) * 1.5f

                        if (swipeMode && isLeftSwipe) {
                            cancelRecording()
                        } else if (isDragging) {
                            if (!swipeMode && !isPeeked) {
                                // Finger lifted after a drag: slide to the nearest screen edge.
                                snapToNearestEdge()
                            }
                        } else if (event.actionMasked == MotionEvent.ACTION_UP) {
                            v.performClick()
                            if (isPeeked) exitPeekMode() else onTap()
                        }
                        restartIdleTimer()
                        return true
                    }
                }
                return false
            }
        }
    }

    // ---------------------------------------------------------------------------------------
    // Snap to edge
    // ---------------------------------------------------------------------------------------

    /** Current screen width in px (window metrics on API 30+, display metrics below). */
    private fun getScreenWidth(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            windowManager.currentWindowMetrics.bounds.width()
        } else {
            resources.displayMetrics.widthPixels
        }
    }

    /**
     * ACTION_UP after a drag: left half -> x = 0, right half -> view's right edge touches the
     * screen's right edge (x = screenWidth - viewWidth), animated with a [ValueAnimator].
     */
    private fun snapToNearestEdge() {
        val root = overlayView ?: return
        val screenWidth = getScreenWidth()
        val viewWidth = if (root.width > 0) root.width else dpToPx(COLLAPSED_BUBBLE_DP)
        val collapsedWidth = dpToPx(COLLAPSED_BUBBLE_DP)

        val snapLeft = layoutParams.x + viewWidth / 2 < screenWidth / 2
        val targetX = if (snapLeft) 0 else (screenWidth - viewWidth).coerceAtLeast(0)

        // Remember the position as the collapsed bubble's, so that collapsing the pill later
        // keeps the bubble glued to the same edge.
        val savedX = if (snapLeft) 0 else (screenWidth - collapsedWidth).coerceAtLeast(0)
        Prefs.saveBubblePosition(this, savedX, layoutParams.y)

        val startX = layoutParams.x
        if (startX == targetX) return

        overlayAnimator?.cancel()
        overlayAnimator = ValueAnimator.ofInt(startX, targetX).apply {
            duration = 250L
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                layoutParams.x = animator.animatedValue as Int
                updateOverlayViewLayout() // windowManager.updateViewLayout(...)
            }
            start()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Visibility (driven by the soft keyboard) — no keyboard clearance maths, ever.
    // ---------------------------------------------------------------------------------------

    private fun onKeyboardStateChanged(isOpen: Boolean) {
        if (isOpen == keyboardOpen) return // ignore keyboard-height changes
        keyboardOpen = isOpen
        if (isOpen) {
            if (!bubbleShown) showBubbleInPeek() else restartIdleTimer()
        } else {
            syncBubbleVisibility()
        }
    }

    /** Hides when the keyboard is closed (deferred while recording / transcribing). */
    private fun syncBubbleVisibility() {
        val shouldShow = keyboardOpen || stateMachine.currentState != BubbleState.IDLE
        if (shouldShow && !bubbleShown) {
            showBubbleInPeek()
        } else if (!shouldShow && bubbleShown) {
            hideBubble()
        }
    }

    /**
     * The bubble never pops up expanded: it appears instantly tucked into the screen edge
     * (nearest to the user's saved position) as a ~22dp semi-transparent tap handle.
     */
    private fun showBubbleInPeek() {
        val root = overlayView ?: return
        overlayAnimator?.cancel()
        cancelIdleTimer()
        isExpanded = false
        expandedPill?.visibility = View.GONE
        collapsedBubble?.visibility = View.VISIBLE
        val (savedX, savedY) = savedPosition()
        layoutParams.x = peekXFor(savedX)
        layoutParams.y = savedY
        isPeeked = true
        bubbleShown = true
        root.alpha = PEEK_ALPHA
        root.visibility = View.VISIBLE
        updateOverlayViewLayout()
    }

    /** X that leaves only the peek handle on screen, on the edge nearest to [referenceX]. */
    private fun peekXFor(referenceX: Int): Int {
        val screenWidth = resources.displayMetrics.widthPixels
        val bubbleWidth = dpToPx(COLLAPSED_BUBBLE_DP)
        val handle = dpToPx(PEEK_HANDLE_DP)
        val dockLeft = referenceX + bubbleWidth / 2 < screenWidth / 2
        return if (dockLeft) -(bubbleWidth - handle) else screenWidth - handle
    }

    private fun hideBubble() {
        cancelIdleTimer()
        overlayAnimator?.cancel()
        isPeeked = false
        bubbleShown = false
        overlayView?.apply {
            alpha = 1f
            visibility = View.GONE
        }
    }

    /** The user's last drop position; only guards against being completely off-screen. */
    private fun savedPosition(): Pair<Int, Int> {
        val (rawX, rawY) = Prefs.getBubblePosition(this, defaultX = 0, defaultY = 280)
        val metrics = resources.displayMetrics
        val handle = dpToPx(PEEK_HANDLE_DP)
        val bubble = dpToPx(COLLAPSED_BUBBLE_DP)
        val x = rawX.coerceIn(-(bubble - handle), (metrics.widthPixels - handle).coerceAtLeast(0))
        val y = rawY.coerceIn(0, (metrics.heightPixels - bubble).coerceAtLeast(0))
        return x to y
    }

    // ---------------------------------------------------------------------------------------
    // Edge-peek / auto-hide
    // ---------------------------------------------------------------------------------------

    private fun restartIdleTimer() {
        mainHandler.removeCallbacks(idleRunnable)
        if (bubbleShown && !isPeeked) {
            mainHandler.postDelayed(idleRunnable, IDLE_PEEK_DELAY_MS)
        }
    }

    private fun cancelIdleTimer() {
        mainHandler.removeCallbacks(idleRunnable)
    }

    private fun enterPeekMode() {
        cancelIdleTimer()
        if (!bubbleShown || isPeeked) return
        // Never dock while the user is recording / waiting for a result.
        if (stateMachine.currentState != BubbleState.IDLE) return

        if (isExpanded) {
            isExpanded = false
            expandedPill?.visibility = View.GONE
            collapsedBubble?.visibility = View.VISIBLE
        }

        val (savedX, savedY) = savedPosition()
        isPeeked = true
        animateOverlay(peekXFor(savedX), savedY, PEEK_ALPHA, ANIM_MS)
    }

    /** Tap on the peek handle: expand fully (mic pill, alpha 1.0) at the saved position. */
    private fun exitPeekMode() {
        val root = overlayView ?: return
        if (!isPeeked) return
        isPeeked = false
        isExpanded = true
        collapsedBubble?.visibility = View.GONE
        expandedPill?.visibility = View.VISIBLE

        // Keep the wider pill fully on screen; the stored coordinates are not modified.
        root.measure(
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED),
            View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED)
        )
        val maxX = (resources.displayMetrics.widthPixels - root.measuredWidth).coerceAtLeast(0)
        val (savedX, savedY) = savedPosition()
        animateOverlay(savedX.coerceIn(0, maxX), savedY, 1f, EXPAND_ANIM_MS)
        restartIdleTimer()
    }

    /** One ValueAnimator drives x, y and alpha together (single layout pass per frame). */
    private fun animateOverlay(targetX: Int, targetY: Int, targetAlpha: Float, durationMs: Long) {
        val root = overlayView ?: return
        overlayAnimator?.cancel()
        val startX = layoutParams.x
        val startY = layoutParams.y
        val startAlpha = root.alpha
        overlayAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = durationMs
            interpolator = DecelerateInterpolator()
            addUpdateListener { animator ->
                val f = animator.animatedValue as Float
                val x = startX + ((targetX - startX) * f).toInt()
                val y = startY + ((targetY - startY) * f).toInt()
                root.alpha = startAlpha + (targetAlpha - startAlpha) * f
                if (x != layoutParams.x || y != layoutParams.y) {
                    layoutParams.x = x
                    layoutParams.y = y
                    updateOverlayViewLayout()
                }
            }
            start()
        }
    }

    private fun toggleExpandedPill() {
        isExpanded = !isExpanded
        if (isExpanded) {
            collapsedBubble?.visibility = View.GONE
            expandedPill?.visibility = View.VISIBLE
        } else {
            expandedPill?.visibility = View.GONE
            collapsedBubble?.visibility = View.VISIBLE
        }
        restartIdleTimer()
        overlayView?.post {
            keepOverlayInsideScreenBounds()
        }
    }

    private fun keepOverlayInsideScreenBounds() {
        // The pill is wider than the bubble: keep it on screen without touching the saved position.
        if (isPeeked) return
        val root = overlayView ?: return
        val (savedX, savedY) = savedPosition()
        val maxX = (resources.displayMetrics.widthPixels - root.width).coerceAtLeast(0)
        layoutParams.x = savedX.coerceIn(0, maxX)
        layoutParams.y = savedY
        updateOverlayViewLayout()
    }

    private fun isNetworkConnected(): Boolean {
        return try {
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return true
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            true
        }
    }

    /**
     * Handles tap on [ 🎙️ MIC ]:
     * - Tap 1 (IDLE -> RECORDING): starts recording raw audio via AudioRecorderManager.
     * - Tap 2 (RECORDING -> PROCESSING): stops recording and sends the audio to Gemini.
     */
    private fun handleMicToggleTap() {
        if (!stateMachine.isMicEnabled()) return

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Microphone permission is required (মাইক্রোফোন পারমিশন প্রয়োজন)", Toast.LENGTH_LONG).show()
            return
        }

        if (stateMachine.currentState == BubbleState.IDLE && Prefs.getApiKey(this).isBlank()) {
            Toast.makeText(
                this,
                "Add your Gemini API key in Settings (সেটিংসে এপিআই কী দিন)",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        when (stateMachine.onMicTapped()) {
            BubbleState.RECORDING -> {
                vibrateShort()
                val startResult = audioRecorder.startRecording()
                if (startResult.isFailure) {
                    stateMachine.resetToIdle()
                    Toast.makeText(
                        this,
                        "Could not start microphone: ${startResult.exceptionOrNull()?.localizedMessage ?: "Error"}",
                        Toast.LENGTH_SHORT
                    ).show()
                    return
                }
                startRecordingTimer()
            }

            BubbleState.PROCESSING -> {
                vibrateShort()
                stopRecordingTimer()
                val recordedFile = audioRecorder.stopRecording()
                if (recordedFile == null) {
                    stateMachine.resetToIdle()
                    Toast.makeText(this, "No speech detected (খুব কম সময় কথা বলা হয়েছে).", Toast.LENGTH_SHORT).show()
                    return
                }
                startGeminiTranscription(recordedFile)
            }

            else -> Unit
        }
    }

    private fun startGeminiTranscription(audioFile: File) {
        val apiKey = Prefs.getApiKey(this)
        val configuredModel = Prefs.getModelName(this)
        // Captured now (before the network call) so the tone matches the app the user is typing in.
        val appPackage = VoiceTypeAccessibilityService.currentAppPackage(this)

        transcriptionJob?.cancel()
        transcriptionJob = serviceScope.launch {
            try {
                val result = RacingTranscriber.transcribeAudio(
                    audioFile = audioFile,
                    apiKey = apiKey,
                    configuredModel = configuredModel,
                    appPackage = appPackage
                )
                result.fold(
                    onSuccess = { response ->
                        if (response.usedFallbackModel) {
                            Toast.makeText(
                                this@FloatingBubbleService,
                                "Model '$configuredModel' not found (404). Retried with '${Prefs.FALLBACK_MODEL_NAME}'.",
                                Toast.LENGTH_LONG
                            ).show()
                        }
                        completeSuccessfulTranscription(
                            text = response.text,
                            modelLabel = response.modelUsed
                        )
                    },
                    onFailure = { error ->
                        stateMachine.resetToIdle()
                        val msg = when (error) {
                            is TranscriptionException.ModelNotFound -> error.localizedMessage ?: "Model not found (404)."
                            is TranscriptionException.EmptyResult -> "No speech detected (কোনো কথা শনাক্ত হয়নি)।"
                            is TranscriptionException.InvalidApiKey -> "Invalid Gemini API key. Please check your key in VoiceType Pro."
                            is TranscriptionException.QuotaExceeded -> "Quota limit reached (429). Please wait a moment."
                            is TranscriptionException.NoInternet -> "No internet connection. Please check network."
                            else -> error.localizedMessage ?: "Transcription failed."
                        }
                        Toast.makeText(
                            this@FloatingBubbleService,
                            msg,
                            Toast.LENGTH_LONG
                        ).show()
                    }
                )
            } catch (_: CancellationException) {
                audioRecorder.deleteFileSafely(audioFile)
                stateMachine.resetToIdle()
            } catch (e: Exception) {
                audioRecorder.deleteFileSafely(audioFile)
                stateMachine.resetToIdle()
                Toast.makeText(
                    this@FloatingBubbleService,
                    e.localizedMessage ?: "Transcription error",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private suspend fun completeSuccessfulTranscription(text: String, modelLabel: String) {
        Prefs.addHistoryItem(
            context = this@FloatingBubbleService,
            text = text,
            modelUsed = modelLabel
        )

        val outcome = VoiceTypeAccessibilityService.insertTranscribedTextWithRetry(
            context = this@FloatingBubbleService,
            text = text
        )
        if (outcome == InsertionOutcome.COPIED_ONLY_MANUAL_PASTE) {
            val message = if (!VoiceTypeAccessibilityService.isHealthy()) {
                "Accessibility service is not responding. Turn \"VoiceType Pro Auto-Type\" OFF and ON again " +
                    "(text copied — long-press and Paste)"
            } else {
                "Copied — long-press the text box and Paste"
            }
            Toast.makeText(this@FloatingBubbleService, message, Toast.LENGTH_LONG).show()
        }

        if (stateMachine.onTranscriptionSuccess()) {
            delay(1_000L)
            stateMachine.resetToIdle()
        } else {
            stateMachine.resetToIdle()
        }
        // Transcription finished: tuck back into the edge-peek state.
        enterPeekMode()
    }

    /**
     * Handles tap on [ ✕ CROSS ] according to the current state:
     * - While RECORDING -> stop recording, delete audio file, return to IDLE, show "Cancelled" toast.
     * - While PROCESSING -> cancel coroutine and OkHttp call, return to IDLE.
     * - While IDLE -> if last transcription was inserted < 30s ago, UNDO it; otherwise collapse pill to bubble.
     */
    private fun handleCrossTap() {
        when (stateMachine.currentState) {
            BubbleState.RECORDING -> cancelRecording()

            BubbleState.PROCESSING -> {
                RacingTranscriber.cancelActiveRequest()
                GeminiTranscriber.cancelActiveRequest()
                transcriptionJob?.cancel()
                transcriptionJob = null
                stateMachine.onCancelToIdle()
                Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
            }

            BubbleState.IDLE, BubbleState.INSERTED -> {
                if (TextInserter.canUndo()) {
                    val undone = VoiceTypeAccessibilityService.performUndoIfAvailable(this)
                    if (undone) {
                        vibrateShort()
                        Toast.makeText(this, "Undid last transcription", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(
                            this,
                            "Focus the text box to undo, or undo expired",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    if (isExpanded) {
                        toggleExpandedPill()
                    }
                }
            }
        }
    }

    /**
     * Stops the current recording, discards the audio and returns to IDLE.
     * Used by the ✕ button and by the swipe-left gesture on the mic button.
     */
    private fun cancelRecording() {
        if (stateMachine.currentState != BubbleState.RECORDING) return
        stopRecordingTimer()
        audioRecorder.cancelAndDeleteRecording()
        stateMachine.onCancelToIdle()
        vibrateShort()
        Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show()
    }

    private fun startRecordingTimer() {
        elapsedSeconds = 0
        updateTimerLabel(0)
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive && stateMachine.currentState == BubbleState.RECORDING) {
                delay(1_000L)
                elapsedSeconds += 1
                updateTimerLabel(elapsedSeconds)
                if (elapsedSeconds >= 120) {
                    handleMicToggleTap()
                    break
                }
            }
        }
    }

    private fun stopRecordingTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    private fun updateTimerLabel(seconds: Int) {
        val mins = seconds / 60
        val secs = seconds % 60
        txtMicLabel?.text = String.format(Locale.US, "%02d:%02d", mins, secs)
    }

    private fun renderBubbleState(state: BubbleState) {
        val micButton = btnMic ?: return
        val micIcon = imgMicState ?: return
        val spinner = progressMic ?: return
        val label = txtMicLabel ?: return

        stopPulseAnimation()

        when (state) {
            BubbleState.IDLE -> {
                micButton.isEnabled = true
                micButton.background = getDrawable(R.drawable.bg_btn_mic_idle)
                micIcon.visibility = View.VISIBLE
                micIcon.setImageResource(R.drawable.ic_mic_white)
                spinner.visibility = View.GONE
                label.text = "MIC"
                collapsedBubble?.background = getDrawable(R.drawable.bg_bubble_circle)
            }

            BubbleState.RECORDING -> {
                micButton.isEnabled = true
                micButton.background = getDrawable(R.drawable.bg_btn_mic_recording)
                micIcon.visibility = View.VISIBLE
                micIcon.setImageResource(R.drawable.ic_mic_white)
                spinner.visibility = View.GONE
                updateTimerLabel(elapsedSeconds)
                startPulseAnimation(micButton)
                collapsedBubble?.background = getDrawable(R.drawable.bg_btn_mic_recording)
            }

            BubbleState.PROCESSING -> {
                micButton.isEnabled = false
                micButton.background = getDrawable(R.drawable.bg_btn_mic_processing)
                micIcon.visibility = View.GONE
                spinner.visibility = View.VISIBLE
                label.text = "WAIT…"
                collapsedBubble?.background = getDrawable(R.drawable.bg_btn_mic_processing)
            }

            BubbleState.INSERTED -> {
                micButton.isEnabled = false
                micButton.background = getDrawable(R.drawable.bg_btn_mic_inserted)
                micIcon.visibility = View.VISIBLE
                micIcon.setImageResource(R.drawable.ic_check_white)
                spinner.visibility = View.GONE
                label.text = "✓"
                collapsedBubble?.background = getDrawable(R.drawable.bg_btn_mic_inserted)
            }
        }
    }

    private fun startPulseAnimation(target: View) {
        val scaleX = PropertyValuesHolder.ofFloat(View.SCALE_X, 1.0f, 1.06f)
        val scaleY = PropertyValuesHolder.ofFloat(View.SCALE_Y, 1.0f, 1.06f)
        val alpha = PropertyValuesHolder.ofFloat(View.ALPHA, 1.0f, 0.82f)
        pulseAnimator = ObjectAnimator.ofPropertyValuesHolder(target, scaleX, scaleY, alpha).apply {
            duration = 550L
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            start()
        }
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        btnMic?.apply {
            scaleX = 1.0f
            scaleY = 1.0f
            alpha = 1.0f
        }
    }

    private fun vibrateShort() {
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(
                        VibrationEffect.createOneShot(45L, VibrationEffect.DEFAULT_AMPLITUDE)
                    )
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(45L)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun updateOverlayViewLayout() {
        val view = overlayView ?: return
        try {
            windowManager.updateViewLayout(view, layoutParams)
        } catch (_: Exception) {
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    override fun onDestroy() {
        _isRunningFlow.value = false
        VoiceTypeAccessibilityService.onKeyboardStateChanged = null
        cancelIdleTimer()
        overlayAnimator?.cancel()
        stopRecordingTimer()
        stopPulseAnimation()
        RacingTranscriber.cancelActiveRequest()
        GeminiTranscriber.cancelActiveRequest()
        transcriptionJob?.cancel()
        audioRecorder.cancelAndDeleteRecording()
        serviceScope.cancel()

        overlayView?.let { view ->
            try {
                windowManager.removeView(view)
            } catch (_: Exception) {
            }
        }
        overlayView = null
        super.onDestroy()
    }
}
