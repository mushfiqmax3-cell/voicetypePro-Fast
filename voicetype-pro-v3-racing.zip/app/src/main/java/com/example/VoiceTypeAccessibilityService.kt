package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.ComponentName
import android.content.Context
import android.graphics.Rect
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.view.inputmethod.InputMethodManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Soft keyboard (IME) state as seen through AccessibilityWindowInfo.TYPE_INPUT_METHOD. */
data class KeyboardState(val visible: Boolean, val topY: Int)

/**
 * AccessibilityService that tracks the focused editable text field and the soft keyboard in any
 * external app, so VoiceType Pro can insert transcribed text and keep the bubble above the keyboard.
 *
 * It never relies on rootInActiveWindow alone: on aggressive OEM ROMs (Vivo OriginOS, etc.) that
 * root can be null after the process is restarted, so every lookup also walks [getWindows].
 */
class VoiceTypeAccessibilityService : AccessibilityService() {

    companion object {
        private const val CONTENT_CHANGED_THROTTLE_MS = 250L
        private const val MAX_TREE_DEPTH = 40
        private const val MIN_KEYBOARD_HEIGHT_PX = 100

        @Volatile
        var instance: VoiceTypeAccessibilityService? = null
            private set

        @Volatile
        var lastFocusedEditableNode: AccessibilityNodeInfo? = null
            private set

        // These flows live in the companion (process-wide), so FloatingBubbleService can collect them
        // no matter which of the two services was restarted first.
        private val _textFieldFocused = MutableStateFlow(false)

        /** True while an editable text field (in any other app) has input focus. */
        val textFieldFocused: StateFlow<Boolean> = _textFieldFocused.asStateFlow()

        private val _keyboardState = MutableStateFlow(KeyboardState(visible = false, topY = 0))

        /** Soft keyboard visibility and the Y coordinate (screen px) of its top edge. */
        val keyboardState: StateFlow<KeyboardState> = _keyboardState.asStateFlow()

        /**
         * Live keyboard callback: (isOpen, keyboardTopY in screen px). Invoked on the main thread
         * whenever the IME window opens, closes or moves. Setting it immediately replays the
         * current state so a late subscriber (e.g. after an auto-restart) is never out of sync.
         */
        @Volatile
        var onKeyboardStateChanged: ((isOpen: Boolean, keyboardTopY: Int) -> Unit)? = null
            set(value) {
                field = value
                val current = _keyboardState.value
                value?.invoke(current.visible, current.topY)
            }

        @Volatile
        private var lastAppPackage: String? = null

        /**
         * True when the service is connected AND can actually see windows. After a background kill
         * some ROMs leave a "zombie" connection whose windows / root are empty; the fix is to turn
         * the service OFF and ON again in Accessibility settings.
         */
        fun isHealthy(): Boolean {
            val svc = instance ?: return false
            return try {
                svc.rootInActiveWindow != null || svc.windows.isNotEmpty()
            } catch (_: Exception) {
                false
            }
        }

        /**
         * Package name of the app the user is currently typing into (e.g. com.google.android.gm),
         * or null if unknown. Our own package and keyboard (IME) packages are never returned.
         */
        fun currentAppPackage(context: Context): String? {
            val svc = instance
            val fromNode = try {
                lastFocusedEditableNode?.packageName?.toString()
            } catch (_: Exception) {
                null
            }
            val fromRoot = try {
                svc?.rootInActiveWindow?.packageName?.toString()
            } catch (_: Exception) {
                null
            }
            return listOf(fromRoot, fromNode, lastAppPackage)
                .firstOrNull { !it.isNullOrBlank() && it != context.packageName && !isImePackage(context, it) }
        }

        private fun isImePackage(context: Context, pkg: String): Boolean {
            return try {
                val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                imm?.enabledInputMethodList?.any { it.packageName == pkg } == true
            } catch (_: Exception) {
                false
            }
        }

        /**
         * Inserts transcribed text into the focused input field (Tier 1 ACTION_SET_TEXT, Tier 2
         * clipboard + automatic ACTION_PASTE). Returns the detailed outcome.
         */
        fun insertTranscribedText(
            context: Context,
            text: String,
            allowFallbacks: Boolean = true
        ): InsertionOutcome {
            return TextInserter.insertTextDetailed(
                context = context,
                service = instance,
                cachedFocusedNode = lastFocusedEditableNode,
                transcribedText = text,
                allowFallbacks = allowFallbacks
            )
        }

        /**
         * Retries the 2-tier insertion (the target window can be briefly unavailable right after the
         * network call returns, e.g. after a background auto-restart).
         */
        suspend fun insertTranscribedTextWithRetry(context: Context, text: String): InsertionOutcome {
            val attempts = 3
            var outcome = InsertionOutcome.COPIED_ONLY_MANUAL_PASTE
            for (i in 1..attempts) {
                val last = i == attempts
                outcome = insertTranscribedText(context, text)
                if (outcome == InsertionOutcome.INSERTED_DIRECTLY ||
                    outcome == InsertionOutcome.PASTED_VIA_CLIPBOARD
                ) {
                    return outcome
                }
                if (!last) {
                    instance?.refreshState()
                    delay(200L)
                }
            }
            return outcome
        }

        /** Undoes the last inserted transcription if performed within 30 seconds. */
        fun performUndoIfAvailable(context: Context): Boolean {
            return TextInserter.undoLastInsertion(
                context = context,
                service = instance,
                cachedFocusedNode = lastFocusedEditableNode
            )
        }

        /** Checks whether VoiceTypeAccessibilityService is enabled in system Accessibility settings. */
        fun isServiceEnabled(context: Context): Boolean {
            if (instance != null) return true
            val expectedComponent = ComponentName(context, VoiceTypeAccessibilityService::class.java)
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false

            val splitter = TextUtils.SimpleStringSplitter(':')
            splitter.setString(enabledServices)
            while (splitter.hasNext()) {
                val enabledComponent = ComponentName.unflattenFromString(splitter.next())
                if (enabledComponent != null && enabledComponent == expectedComponent) {
                    return true
                }
            }
            return false
        }
    }

    private var lastScanMs = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        applyServiceInfoDefensively()
        refreshState()
    }

    /**
     * Some OEM skins ignore parts of the XML config after a restart, so the important flags are
     * re-applied in code. Failure here is harmless (the XML values still apply).
     */
    private fun applyServiceInfoDefensively() {
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.eventTypes = AccessibilityEvent.TYPE_WINDOWS_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_VIEW_FOCUSED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
            info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            info.notificationTimeout = 50
            serviceInfo = info
        } catch (_: Exception) {
        }
    }

    /** Re-reads keyboard + focus state from the window list (used on connect and before retries). */
    fun refreshState() {
        updateKeyboardState()
        val node = findCurrentInputNode()
        _textFieldFocused.value = node != null
        if (node != null) lastFocusedEditableNode = node
    }

    // NOTE: AccessibilityService has no onWindowsChanged() callback; window changes are delivered
    // as TYPE_WINDOWS_CHANGED events (enabled in the config), handled right here.
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val type = event.eventType

        // TYPE_WINDOW_CONTENT_CHANGED fires extremely often; throttle it.
        val now = SystemClock.uptimeMillis()
        if (type == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
            now - lastScanMs < CONTENT_CHANGED_THROTTLE_MS
        ) {
            return
        }
        lastScanMs = now

        // Keyboard state is derived from the window list and must be updated before any package filtering
        // (the IME's own events are exactly what tells us the keyboard opened or closed).
        updateKeyboardState()

        val pkg = event.packageName?.toString()
        if (pkg == packageName) return // our own overlay
        if (pkg != null && isImePackage(this, pkg)) return // keyboard window
        if (pkg != null) lastAppPackage = pkg

        if (type == AccessibilityEvent.TYPE_VIEW_FOCUSED) {
            val source = event.source
            if (source != null && source.isEditable) {
                lastFocusedEditableNode = source
                _textFieldFocused.value = true
                return
            }
        }

        val focused = findCurrentInputNode()
        _textFieldFocused.value = focused != null
        if (focused != null) lastFocusedEditableNode = focused
    }

    /** Scans all windows for the IME window and publishes visibility + top edge. */
    private fun updateKeyboardState() {
        var visible = false
        var top = 0
        val rect = Rect()
        val allWindows = try {
            windows
        } catch (_: Exception) {
            emptyList<AccessibilityWindowInfo>()
        }
        for (window in allWindows) {
            if (window.type == AccessibilityWindowInfo.TYPE_INPUT_METHOD) {
                window.getBoundsInScreen(rect)
                if (rect.height() > MIN_KEYBOARD_HEIGHT_PX) {
                    visible = true
                    top = rect.top
                    break
                }
            }
        }
        val newState = KeyboardState(visible = visible, topY = if (visible) top else 0)
        if (newState != _keyboardState.value) {
            _keyboardState.value = newState
            onKeyboardStateChanged?.invoke(newState.visible, newState.topY)
        }
    }

    /**
     * Finds the editable field that currently has input focus without depending only on
     * rootInActiveWindow:
     *  1. findFocus(FOCUS_INPUT) on the active window root (and on each application window root),
     *  2. otherwise walk every TYPE_APPLICATION window and look for isFocused && isEditable.
     * Returns null if nothing is found. Our own overlay is always ignored.
     */
    fun findCurrentInputNode(): AccessibilityNodeInfo? {
        val own = packageName

        try {
            val focused = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            if (focused != null && focused.isEditable && focused.packageName?.toString() != own) {
                return focused
            }
        } catch (_: Exception) {
        }

        val allWindows = try {
            windows
        } catch (_: Exception) {
            return null
        }

        for (window in allWindows) {
            if (window.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val root = try {
                window.root
            } catch (_: Exception) {
                null
            } ?: continue
            if (root.packageName?.toString() == own) continue

            try {
                val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                if (focused != null && focused.isEditable) return focused
            } catch (_: Exception) {
            }

            val found = findFocusedEditable(root, own, 0)
            if (found != null) return found
        }
        return null
    }

    private fun findFocusedEditable(node: AccessibilityNodeInfo?, own: String, depth: Int): AccessibilityNodeInfo? {
        if (node == null || depth > MAX_TREE_DEPTH) return null
        if (node.packageName?.toString() == own) return null
        if (node.isFocused && node.isEditable) return node
        for (i in 0 until node.childCount) {
            val child = try {
                node.getChild(i)
            } catch (_: Exception) {
                null
            } ?: continue
            val found = findFocusedEditable(child, own, depth + 1)
            if (found != null) return found
        }
        return null
    }

    override fun onInterrupt() {
        // Required override for AccessibilityService
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        clearState()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        clearState()
        super.onDestroy()
    }

    private fun clearState() {
        if (instance === this) {
            instance = null
        }
        lastFocusedEditableNode = null
        _textFieldFocused.value = false
        _keyboardState.value = KeyboardState(visible = false, topY = 0)
        onKeyboardStateChanged?.invoke(false, 0)
    }
}
