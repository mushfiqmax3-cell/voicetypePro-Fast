package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Bundle
import android.view.accessibility.AccessibilityNodeInfo

data class UndoSnapshot(
    val previousText: String,
    val previousCursorIndex: Int,
    val insertedText: String,
    val timestampMs: Long
)

enum class InsertionOutcome {
    INSERTED_DIRECTLY,
    PASTED_VIA_CLIPBOARD,
    COPIED_ONLY_MANUAL_PASTE
}

/**
 * Handles cursor-aware text insertion into the focused editable AccessibilityNodeInfo found by
 * VoiceTypeAccessibilityService.findCurrentInputNode(), automated clipboard-paste fallback, and 30-second Undo.
 */
object TextInserter {
    const val UNDO_WINDOW_MS = 30_000L

    @Volatile
    private var lastUndoSnapshot: UndoSnapshot? = null

    /**
     * Checks if there is an active Undo snapshot within the last 30 seconds.
     */
    fun canUndo(nowMs: Long = System.currentTimeMillis()): Boolean {
        val snapshot = lastUndoSnapshot ?: return false
        return (nowMs - snapshot.timestampMs) in 0..UNDO_WINDOW_MS
    }

    fun clearUndo() {
        lastUndoSnapshot = null
    }

    /**
     * Pure helper for computing the new text and cursor index when inserting [newText] at the
     * cursor/selection inside [existingText]. Adds a leading space if the character immediately
     * before the insertion point is not a whitespace or newline.
     */
    fun buildInsertedText(
        existingText: String,
        selectionStart: Int,
        selectionEnd: Int,
        newText: String
    ): Pair<String, Int> {
        val safeLen = existingText.length
        val start = if (selectionStart in 0..safeLen) selectionStart else safeLen
        val end = if (selectionEnd in 0..safeLen) selectionEnd else start
        val minIdx = minOf(start, end)
        val maxIdx = maxOf(start, end)

        val before = existingText.substring(0, minIdx)
        val after = existingText.substring(maxIdx, safeLen)

        val needsLeadingSpace = before.isNotEmpty() &&
            !before.last().isWhitespace() &&
            newText.isNotEmpty() &&
            !newText.first().isWhitespace()

        val textToInsert = if (needsLeadingSpace) " $newText" else newText
        val combined = before + textToInsert + after
        val newCursorIndex = before.length + textToInsert.length
        return combined to newCursorIndex
    }

    /**
     * 2-tier automated injection pipeline (no manual long-press ever required):
     *  Tier 1: ACTION_SET_TEXT (cursor-aware, no clipboard).
     *  Tier 2: if Tier 1 fails/returns false, put the text on the clipboard and IMMEDIATELY fire
     *          ACTION_PASTE on the same node through accessibility.
     * If neither worked (no focused field found), the text simply stays on the clipboard and
     * [InsertionOutcome.COPIED_ONLY_MANUAL_PASTE] is returned so the caller can retry / inform the user.
     *
     * [allowFallbacks] is kept for source compatibility; Tier 2 now always runs when Tier 1 fails.
     */
    @Suppress("UNUSED_PARAMETER")
    fun insertTextDetailed(
        context: Context,
        service: VoiceTypeAccessibilityService?,
        cachedFocusedNode: AccessibilityNodeInfo?,
        transcribedText: String,
        allowFallbacks: Boolean = true
    ): InsertionOutcome {
        val cleanText = transcribedText.trim()
        if (cleanText.isEmpty()) return InsertionOutcome.INSERTED_DIRECTLY

        // Nodes we obtained ourselves (fresh copies) and must recycle. The cached node belongs to
        // the accessibility service and is never recycled here.
        val ownedNodes = mutableListOf<AccessibilityNodeInfo>()
        try {
            val candidates = mutableListOf<AccessibilityNodeInfo>()
            val live = try {
                service?.findCurrentInputNode()
            } catch (_: Exception) {
                null
            }
            if (live != null) {
                ownedNodes.add(live)
                candidates.add(live)
            }
            if (cachedFocusedNode != null && candidates.none { it == cachedFocusedNode }) {
                val usable = try {
                    cachedFocusedNode.refresh() && cachedFocusedNode.isEditable &&
                        cachedFocusedNode.packageName?.toString() != context.packageName
                } catch (_: Exception) {
                    false
                }
                if (usable) candidates.add(cachedFocusedNode)
            }

            // Tier 1: ACTION_SET_TEXT
            for (node in candidates) {
                if (trySetText(node, cleanText)) return InsertionOutcome.INSERTED_DIRECTLY
            }

            // Tier 2: clipboard + automatic ACTION_PASTE
            copyToClipboard(context, cleanText)
            for (node in candidates) {
                if (tryPaste(node, cleanText)) return InsertionOutcome.PASTED_VIA_CLIPBOARD
            }

            return InsertionOutcome.COPIED_ONLY_MANUAL_PASTE
        } finally {
            for (node in ownedNodes) recycleQuietly(node)
        }
    }

    /**
     * Convenience wrapper around [insertTextDetailed].
     * @return true if the text went into the field (tier 1 or 2); false if it was only copied.
     */
    fun insertText(context: Context, service: VoiceTypeAccessibilityService?, text: String): Boolean {
        val outcome = insertTextDetailed(
            context = context,
            service = service,
            cachedFocusedNode = VoiceTypeAccessibilityService.lastFocusedEditableNode,
            transcribedText = text,
            allowFallbacks = true
        )
        return outcome != InsertionOutcome.COPIED_ONLY_MANUAL_PASTE
    }

    /** Tier 2 worker: re-focuses the field (some OEM keyboards drop focus) and pastes the clipboard. */
    private fun tryPaste(node: AccessibilityNodeInfo, cleanText: String): Boolean {
        val currentText = try {
            node.refresh()
            readCurrentText(node)
        } catch (_: Exception) {
            ""
        }
        val prevCursor = node.textSelectionStart.takeIf { it >= 0 } ?: currentText.length
        node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        if (!node.performAction(AccessibilityNodeInfo.ACTION_PASTE)) return false
        lastUndoSnapshot = UndoSnapshot(
            previousText = currentText,
            previousCursorIndex = prevCursor.coerceIn(0, currentText.length),
            insertedText = cleanText,
            timestampMs = System.currentTimeMillis()
        )
        return true
    }

    @Suppress("DEPRECATION")
    private fun recycleQuietly(node: AccessibilityNodeInfo) {
        try {
            node.recycle()
        } catch (_: Exception) {
        }
    }

    // Placeholder / hint phrases some apps (WhatsApp, Messenger, search bars …) expose as the
    // field's "text" even though the field is empty.
    private val PLACEHOLDER_HINTS = setOf(
        "type a message", "message", "search", "write a message", "send a message",
        "enter message", "type here", "aa"
    )

    /**
     * True when the node's reported text is only a hint / placeholder (or empty), i.e. the field
     * has no real user content. In that case the field must be overwritten, never appended to.
     */
    private fun isPlaceholderOnly(node: AccessibilityNodeInfo): Boolean {
        val raw = node.text?.toString()
        if (raw.isNullOrBlank()) return true
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (node.isShowingHintText) return true
            val hint = node.hintText?.toString()?.trim()
            if (!hint.isNullOrEmpty() && raw.trim().equals(hint, ignoreCase = true)) return true
        }
        return raw.trim().lowercase() in PLACEHOLDER_HINTS
    }

    private fun readCurrentText(node: AccessibilityNodeInfo): String {
        return if (isPlaceholderOnly(node)) "" else (node.text?.toString() ?: "")
    }

    /**
     * Refreshes [node], builds the new text around the cursor and applies ACTION_SET_TEXT.
     * Returns true on success and records the 30-second undo snapshot.
     */
    private fun trySetText(node: AccessibilityNodeInfo, cleanText: String): Boolean {
        try {
            node.refresh()
        } catch (_: Exception) {
        }
        val isHint = isPlaceholderOnly(node)
        val currentText = readCurrentText(node)
        val selStart = if (isHint) 0 else node.textSelectionStart
        val selEnd = if (isHint) 0 else node.textSelectionEnd

        val (updatedText, newCursorPos) = buildInsertedText(
            existingText = currentText,
            selectionStart = selStart,
            selectionEnd = selEnd,
            newText = cleanText
        )

        val setArgs = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, updatedText)
        }
        if (!node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)) return false

        // Move cursor to the end of the inserted text
        val selectionArgs = Bundle().apply {
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, newCursorPos)
            putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, newCursorPos)
        }
        node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selectionArgs)

        val prevCursor = (if (selStart >= 0) selStart else currentText.length).coerceIn(0, currentText.length)
        lastUndoSnapshot = UndoSnapshot(
            previousText = currentText,
            previousCursorIndex = prevCursor,
            insertedText = updatedText.substring(minOf(prevCursor, newCursorPos), newCursorPos),
            timestampMs = System.currentTimeMillis()
        )
        return true
    }

    /**
     * Restores the field's previous text if the last insertion occurred less than 30 seconds ago.
     */
    fun undoLastInsertion(
        context: Context,
        service: VoiceTypeAccessibilityService?,
        cachedFocusedNode: AccessibilityNodeInfo?
    ): Boolean {
        val snapshot = lastUndoSnapshot ?: return false
        if (!canUndo()) {
            lastUndoSnapshot = null
            return false
        }
        val activeService = service ?: return false
        val liveNode = try {
            activeService.findCurrentInputNode()
        } catch (_: Exception) {
            null
        }
        try {
            val node = liveNode
                ?: cachedFocusedNode?.takeIf {
                    try {
                        it.refresh() && it.isEditable
                    } catch (_: Exception) {
                        false
                    }
                }
                ?: return false

            val setArgs = Bundle().apply {
                putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                    snapshot.previousText
                )
            }
            val restored = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, setArgs)
            if (restored) {
                val cursor = snapshot.previousCursorIndex.coerceIn(0, snapshot.previousText.length)
                val selArgs = Bundle().apply {
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_START_INT, cursor)
                    putInt(AccessibilityNodeInfo.ACTION_ARGUMENT_SELECTION_END_INT, cursor)
                }
                node.performAction(AccessibilityNodeInfo.ACTION_SET_SELECTION, selArgs)
                lastUndoSnapshot = null
                return true
            }
            return false
        } finally {
            if (liveNode != null) recycleQuietly(liveNode)
        }
    }

    fun copyToClipboard(context: Context, text: String) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val clip = ClipData.newPlainText("VoiceType Pro Transcription", text)
        clipboard?.setPrimaryClip(clip)
    }
}
