package com.example

/**
 * One stored Gemini API key together with the models enabled for it.
 *
 * @param isExhausted true when the key's quota is used up; exhausted keys are skipped by rotation.
 * @param selectedModelIds [GeminiModel.modelId] values enabled for this key (at least one).
 */
data class ApiKeyEntry(
    val id: String,
    val displayName: String,
    val keyValue: String,
    val isExhausted: Boolean = false,
    val selectedModelIds: Set<String> = setOf(GeminiModel.DEFAULT.modelId)
)
