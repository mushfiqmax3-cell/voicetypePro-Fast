package com.example

import android.content.Context
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

/**
 * Size-optimised speech recorder built on [MediaRecorder]:
 * MIC source, MPEG-4 container, AAC encoder, mono, 16 kHz, 32 kbps (~4 KB per second,
 * so a typical dictation is ~15-30 KB and uploads almost instantly).
 *
 * Output is an `.m4a` file in [Context.getCacheDir] (MIME "audio/mp4").
 * Public API is unchanged: [startRecording], [stopRecording], [cancelAndDeleteRecording].
 */
class AudioRecorderManager(
    private val context: Context,
    private val onMaxDurationReached: () -> Unit
) {
    companion object {
        const val SAMPLE_RATE_HZ = 16_000
        const val ENCODING_BITRATE_BPS = 32_000
        const val CHANNEL_COUNT = 1
        const val MAX_DURATION_MS = 120_000
        private const val BYTES_PER_SAMPLE = 2 // 16-bit PCM (used by the WAV/normalisation helpers)
        private const val MIN_RECORDING_MS = 150L
        private const val MIN_FILE_BYTES = 200L
    }

    private var recorder: MediaRecorder? = null
    private var currentOutputFile: File? = null
    private var startedAtMs = 0L
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var isRecording = false

    @Volatile
    var lastPeakAmplitude: Int = 0
        private set

    @Synchronized
    fun startRecording(): Result<File> {
        releaseRecorderQuietly()
        val outputFile = File(context.cacheDir, "voicetype_rec_${System.currentTimeMillis()}.m4a")
        currentOutputFile = outputFile
        lastPeakAmplitude = 0

        return try {
            val mr = createMediaRecorder()
            mr.setAudioSource(MediaRecorder.AudioSource.MIC)
            mr.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            mr.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            mr.setAudioChannels(CHANNEL_COUNT)
            mr.setAudioSamplingRate(SAMPLE_RATE_HZ)
            mr.setAudioEncodingBitRate(ENCODING_BITRATE_BPS)
            mr.setMaxDuration(MAX_DURATION_MS)
            mr.setOutputFile(outputFile.absolutePath)
            mr.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_DURATION_REACHED) {
                    mainHandler.post { onMaxDurationReached() }
                }
            }
            mr.prepare()
            mr.start()
            recorder = mr
            startedAtMs = System.currentTimeMillis()
            isRecording = true
            Result.success(outputFile)
        } catch (e: Exception) {
            releaseRecorderQuietly()
            deleteFileSafely(outputFile)
            currentOutputFile = null
            Result.failure(
                IllegalStateException(
                    "Microphone is unavailable or in use by another app.",
                    e
                )
            )
        }
    }

    @Suppress("DEPRECATION")
    private fun createMediaRecorder(): MediaRecorder =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(context)
        } else {
            MediaRecorder()
        }

    /**
     * Stops recording and returns the finished `.m4a` file, or null when nothing usable was captured
     * (e.g. the user tapped stop immediately).
     */
    @Synchronized
    fun stopRecording(): File? {
        val file = currentOutputFile
        val mr = recorder
        if (mr == null || !isRecording) {
            releaseRecorderQuietly()
            return null
        }
        isRecording = false
        val elapsed = System.currentTimeMillis() - startedAtMs

        try {
            lastPeakAmplitude = maxOf(lastPeakAmplitude, mr.maxAmplitude)
        } catch (_: Exception) {
        }

        val stopped = try {
            mr.stop()
            true
        } catch (_: Exception) {
            // Thrown when stop() is called before any audio was encoded.
            false
        }
        releaseRecorderQuietly()

        if (!stopped || file == null || elapsed < MIN_RECORDING_MS ||
            !file.exists() || file.length() < MIN_FILE_BYTES
        ) {
            deleteFileSafely(file)
            return null
        }
        return file
    }

    /**
     * Stops recording immediately and deletes any temporary audio file (used when ✕ is tapped).
     */
    @Synchronized
    fun cancelAndDeleteRecording() {
        val file = currentOutputFile
        isRecording = false
        try {
            recorder?.stop()
        } catch (_: Exception) {
        }
        releaseRecorderQuietly()
        deleteFileSafely(file)
        currentOutputFile = null
    }

    private fun releaseRecorderQuietly() {
        isRecording = false
        val mr = recorder
        recorder = null
        try {
            mr?.setOnInfoListener(null)
            mr?.reset()
        } catch (_: Exception) {
        }
        try {
            mr?.release()
        } catch (_: Exception) {
        }
    }

    /**
     * Normalizes 16-bit little-endian PCM audio if the microphone gain is low,
     * ensuring Gemini receives a strong, clear speech signal without clipping.
     */
    fun normalizePcm16Le(pcmBytes: ByteArray): ByteArray {
        val sampleCount = pcmBytes.size / 2
        if (sampleCount == 0) return pcmBytes

        var peak = 0
        for (i in 0 until sampleCount) {
            val low = pcmBytes[i * 2].toInt() and 0xFF
            val high = pcmBytes[i * 2 + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toInt()
            val absSample = abs(sample)
            if (absSample > peak) peak = absSample
        }

        // If peak is already strong (>= 22000) or completely zero, return as-is
        if (peak == 0 || peak >= 22_000) {
            return pcmBytes
        }

        // Compute safe gain multiplier (up to 30x) so quiet or distant speech reaches ~24,000 peak
        val targetPeak = 24_000.0
        val gain = (targetPeak / peak.toDouble()).coerceIn(1.0, 30.0)

        val out = ByteArray(pcmBytes.size)
        for (i in 0 until sampleCount) {
            val low = pcmBytes[i * 2].toInt() and 0xFF
            val high = pcmBytes[i * 2 + 1].toInt()
            val sample = ((high shl 8) or low).toShort().toInt()
            val boosted = (sample * gain).toInt().coerceIn(-32767, 32767)
            out[i * 2] = (boosted and 0xFF).toByte()
            out[i * 2 + 1] = ((boosted shr 8) and 0xFF).toByte()
        }
        return out
    }

    /**
     * Writes a standard 44-byte RIFF WAVE header followed by 16-bit mono PCM data.
     */
    fun writeWavFile(outputFile: File, pcmData: ByteArray, sampleRate: Int) {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * BYTES_PER_SAMPLE

        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN).apply {
            put("RIFF".toByteArray(Charsets.US_ASCII))
            putInt(totalDataLen)
            put("WAVE".toByteArray(Charsets.US_ASCII))
            put("fmt ".toByteArray(Charsets.US_ASCII))
            putInt(16) // Subchunk1Size for PCM
            putShort(1) // AudioFormat = 1 (PCM)
            putShort(1) // NumChannels = 1 (Mono)
            putInt(sampleRate)
            putInt(byteRate)
            putShort(BYTES_PER_SAMPLE.toShort()) // BlockAlign
            putShort(16) // BitsPerSample
            put("data".toByteArray(Charsets.US_ASCII))
            putInt(pcmData.size)
        }.array()

        FileOutputStream(outputFile).use { fos ->
            fos.write(header)
            fos.write(pcmData)
            fos.flush()
            try {
                fos.fd.sync()
            } catch (_: Exception) {
            }
        }
    }

    fun deleteFileSafely(file: File?) {
        try {
            if (file != null && file.exists()) {
                file.delete()
            }
        } catch (_: Exception) {
        }
    }
}
