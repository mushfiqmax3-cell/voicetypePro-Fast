package com.example

import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Stores [ApiKeyEntry] items as a JSON array under [STORAGE_KEY] in the (encrypted) SharedPreferences
 * handed over by [Prefs]. All mutations are synchronized and published through [entriesFlow].
 */
object ApiKeyRepository {
    const val STORAGE_KEY = "api_key_entries_v2"

    /** Max number of active (non-exhausted) key x model combinations that may run in parallel. */
    const val MAX_CONCURRENT_CALLS = 5

    private val lock = Any()

    @Volatile
    private var prefs: SharedPreferences? = null

    private val _entriesFlow = MutableStateFlow<List<ApiKeyEntry>>(emptyList())
    val entriesFlow: StateFlow<List<ApiKeyEntry>> = _entriesFlow.asStateFlow()

    val isInitialized: Boolean get() = prefs != null

    /**
     * Idempotent. Loads the stored entries; when none exist yet, migrates [legacyKeys]
     * (the old plain key list) once, enabling [defaultModelId] on each.
     */
    fun init(securePrefs: SharedPreferences, legacyKeys: List<String>, defaultModelId: String) {
        synchronized(lock) {
            if (prefs != null) return
            prefs = securePrefs
            val raw = securePrefs.getString(STORAGE_KEY, null)
            val loaded = if (raw != null) {
                parse(raw)
            } else {
                val modelId = GeminiModel.fromId(defaultModelId)?.modelId ?: GeminiModel.DEFAULT.modelId
                val migrated = legacyKeys.mapIndexed { i, key ->
                    ApiKeyEntry(
                        id = newId(),
                        displayName = "Key ${i + 1}",
                        keyValue = key,
                        selectedModelIds = setOf(modelId)
                    )
                }
                persist(migrated)
                migrated
            }
            _entriesFlow.value = loaded
        }
    }

    // ----------------------------------------------------------------------------------------
    // Read
    // ----------------------------------------------------------------------------------------

    fun getAll(): List<ApiKeyEntry> = _entriesFlow.value

    fun getById(id: String): ApiKeyEntry? = _entriesFlow.value.firstOrNull { it.id == id }

    /** Key values that are not exhausted; if every key is exhausted, all keys (last-resort retry). */
    fun getUsableKeyValues(): List<String> {
        val all = _entriesFlow.value
        val active = all.filter { !it.isExhausted }
        return (if (active.isEmpty()) all else active).map { it.keyValue }
    }

    /** Number of active Key x Model combinations (exhausted keys excluded). */
    fun activeCombinationCount(entries: List<ApiKeyEntry> = _entriesFlow.value): Int =
        entries.filter { !it.isExhausted }.sumOf { it.selectedModelIds.size }

    fun exceedsConcurrencyLimit(entries: List<ApiKeyEntry> = _entriesFlow.value): Boolean =
        activeCombinationCount(entries) > MAX_CONCURRENT_CALLS

    // ----------------------------------------------------------------------------------------
    // Create / Update / Delete
    // ----------------------------------------------------------------------------------------

    /**
     * Adds a key. Returns null for a blank key, a duplicate key value, or an empty model set.
     * A blank [displayName] becomes "Key N".
     */
    fun add(
        keyValue: String,
        displayName: String = "",
        modelIds: Set<String> = setOf(GeminiModel.DEFAULT.modelId)
    ): ApiKeyEntry? = synchronized(lock) {
        val cleanKey = keyValue.trim()
        val cleanModels = sanitizeModels(modelIds)
        val current = _entriesFlow.value
        if (cleanKey.isEmpty() || cleanModels.isEmpty() || current.any { it.keyValue == cleanKey }) {
            return null
        }
        val entry = ApiKeyEntry(
            id = newId(),
            displayName = displayName.trim().ifEmpty { "Key ${current.size + 1}" },
            keyValue = cleanKey,
            selectedModelIds = cleanModels
        )
        commit(current + entry)
        entry
    }

    fun rename(id: String, displayName: String): Boolean =
        mutate(id) { it.copy(displayName = displayName.trim().ifEmpty { it.displayName }) }

    /** Rejects (returns false) an empty selection: every key needs at least one model. */
    fun updateModels(id: String, modelIds: Set<String>): Boolean {
        val clean = sanitizeModels(modelIds)
        if (clean.isEmpty()) return false
        return mutate(id) { it.copy(selectedModelIds = clean) }
    }

    fun setExhausted(id: String, exhausted: Boolean): Boolean =
        mutate(id) { it.copy(isExhausted = exhausted) }

    /** Marks the entry that owns [keyValue] as exhausted (for the transcriber's 429 handling). */
    fun markKeyExhausted(keyValue: String): Boolean = synchronized(lock) {
        val target = _entriesFlow.value.firstOrNull { it.keyValue == keyValue } ?: return false
        setExhausted(target.id, true)
    }

    fun resetAllExhausted() = synchronized(lock) {
        val current = _entriesFlow.value
        if (current.any { it.isExhausted }) commit(current.map { it.copy(isExhausted = false) })
    }

    fun delete(id: String): Boolean = synchronized(lock) {
        val current = _entriesFlow.value
        if (current.none { it.id == id }) return false
        commit(current.filter { it.id != id })
        true
    }

    fun deleteByKeyValue(keyValue: String): Boolean {
        val id = _entriesFlow.value.firstOrNull { it.keyValue == keyValue.trim() }?.id ?: return false
        return delete(id)
    }

    // ----------------------------------------------------------------------------------------
    // Internals
    // ----------------------------------------------------------------------------------------

    private fun mutate(id: String, transform: (ApiKeyEntry) -> ApiKeyEntry): Boolean =
        synchronized(lock) {
            val current = _entriesFlow.value
            if (current.none { it.id == id }) return false
            commit(current.map { if (it.id == id) transform(it) else it })
            true
        }

    private fun commit(list: List<ApiKeyEntry>) {
        persist(list)
        _entriesFlow.value = list
    }

    private fun newId(): String = UUID.randomUUID().toString()

    /** Keeps only known model ids so a retired id can never be counted or sent. */
    private fun sanitizeModels(ids: Set<String>): Set<String> =
        ids.mapNotNull { GeminiModel.fromId(it)?.modelId }.toCollection(LinkedHashSet())

    private fun persist(list: List<ApiKeyEntry>) {
        prefs?.edit()?.putString(STORAGE_KEY, serialize(list))?.apply()
    }

    internal fun serialize(list: List<ApiKeyEntry>): String {
        val array = JSONArray()
        list.forEach { e ->
            array.put(
                JSONObject().apply {
                    put("id", e.id)
                    put("displayName", e.displayName)
                    put("keyValue", e.keyValue)
                    put("isExhausted", e.isExhausted)
                    put("selectedModelIds", JSONArray(e.selectedModelIds.toList()))
                }
            )
        }
        return array.toString()
    }

    internal fun parse(raw: String): List<ApiKeyEntry> = try {
        val array = JSONArray(raw)
        val out = ArrayList<ApiKeyEntry>()
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val key = o.optString("keyValue", "").trim()
            if (key.isEmpty()) continue
            val modelsJson = o.optJSONArray("selectedModelIds")
            val models = LinkedHashSet<String>()
            if (modelsJson != null) {
                for (j in 0 until modelsJson.length()) models.add(modelsJson.optString(j, ""))
            }
            out.add(
                ApiKeyEntry(
                    id = o.optString("id", "").ifEmpty { newId() },
                    displayName = o.optString("displayName", "").ifEmpty { "Key ${i + 1}" },
                    keyValue = key,
                    isExhausted = o.optBoolean("isExhausted", false),
                    selectedModelIds = sanitizeModels(models)
                        .ifEmpty { setOf(GeminiModel.DEFAULT.modelId) }
                )
            )
        }
        out
    } catch (_: Exception) {
        emptyList()
    }
}
