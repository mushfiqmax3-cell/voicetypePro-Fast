package com.example

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

data class TranscriptionRecord(
    val id: Long,
    val text: String,
    val timestamp: Long,
    val modelUsed: String
)

/**
 * Manages secure storage for the Gemini API keys (multi-key list with round-robin rotation)
 * via EncryptedSharedPreferences,
 * model configuration, keyboard-sync setting,
 * last floating bubble position, and the last 20 transcriptions.
 */
object Prefs {
    private const val ENCRYPTED_PREFS_NAME = "voicetype_secure_prefs"
    private const val STANDARD_PREFS_NAME = "voicetype_standard_prefs"

    private const val KEY_API_KEY = "gemini_api_key"
    private const val KEY_API_KEYS_JSON = "gemini_api_keys_json"
    private const val KEY_SEEDED_INITIAL = "seeded_initial_key"
    private const val KEY_MODEL_MIGRATED_15_FLASH = "model_migrated_15_flash"
    private const val KEY_MODEL_NAME = "gemini_model_name"
    private const val KEY_SYNC_KEYBOARD = "sync_with_keyboard"
    // Same storage names as before, so an existing saved position survives the update.
    private const val KEY_SAVED_X = "bubble_pos_x"
    private const val KEY_SAVED_Y = "bubble_pos_y"
    private const val KEY_HISTORY_JSON = "transcription_history_json"

    const val DEFAULT_MODEL_NAME = "gemini-1.5-flash"
    const val FALLBACK_MODEL_NAME = "gemini-3.5-flash-lite"
    private const val MAX_HISTORY_ITEMS = 20

    /** Application context captured in [init] so the key-list API can be context-free. */
    @Volatile
    private var appContext: Context? = null

    @Volatile
    private var cachedSecurePrefs: SharedPreferences? = null

    private val keysLock = Any()

    @Volatile
    private var keysCache: List<String>? = null

    /** Round-robin pointer; atomic so concurrent transcriptions never pick the same slot twice. */
    private val rotationIndex = AtomicInteger(0)

    private val _historyFlow = MutableStateFlow<List<TranscriptionRecord>>(emptyList())
    val historyFlow: StateFlow<List<TranscriptionRecord>> = _historyFlow.asStateFlow()

    private val _syncKeyboardFlow = MutableStateFlow(false)
    val syncKeyboardFlow: StateFlow<Boolean> = _syncKeyboardFlow.asStateFlow()

    private fun getSecurePrefs(context: Context): SharedPreferences {
        cachedSecurePrefs?.let { return it }
        return synchronized(this) {
            cachedSecurePrefs ?: createSecurePrefs(context).also { cachedSecurePrefs = it }
        }
    }

    private fun createSecurePrefs(context: Context): SharedPreferences {
        return try {
            val masterKey = MasterKey.Builder(context.applicationContext)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            EncryptedSharedPreferences.create(
                context.applicationContext,
                ENCRYPTED_PREFS_NAME,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        } catch (e: Exception) {
            context.applicationContext.getSharedPreferences(ENCRYPTED_PREFS_NAME, Context.MODE_PRIVATE)
        }
    }

    private fun getStandardPrefs(context: Context): SharedPreferences {
        return context.applicationContext.getSharedPreferences(STANDARD_PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun init(context: Context) {
        appContext = context.applicationContext
        // Loads the key list, migrating the legacy single key / build-time key on first run.
        loadKeys(context.applicationContext)

        // Migrate legacy / retired model names (gemini-3.5-transcribe, gemini-2.x) to the current default
        val stdPrefs = getStandardPrefs(context)
        val currentModel = stdPrefs.getString(KEY_MODEL_NAME, null)
        if (currentModel == null || currentModel == "gemini-3.5-transcribe" || currentModel.startsWith("gemini-2.")) {
            stdPrefs.edit().putString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME).apply()
        }
        // One-time: the previous default (gemini-3.8-flash) moves to the low-latency default.
        // Any model the user picks afterwards is kept.
        if (!stdPrefs.getBoolean(KEY_MODEL_MIGRATED_15_FLASH, false)) {
            val editor = stdPrefs.edit().putBoolean(KEY_MODEL_MIGRATED_15_FLASH, true)
            if (currentModel == "gemini-3.8-flash") editor.putString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME)
            editor.apply()
        }

        ensureRepository(context.applicationContext)

        _syncKeyboardFlow.value = getSyncWithKeyboard(context)
        _historyFlow.value = loadHistory(context)
    }

    /** Idempotent: loads (or migrates the legacy list into) the "api_key_entries_v2" store. */
    private fun ensureRepository(context: Context) {
        if (ApiKeyRepository.isInitialized) return
        ApiKeyRepository.init(
            securePrefs = getSecurePrefs(context),
            legacyKeys = loadKeys(context),
            defaultModelId = getModelName(context)
        )
    }

    // ---------------------------------------------------------------------------------------
    // Multi-key storage
    // ---------------------------------------------------------------------------------------

    private fun buildConfigKeyOrNull(): String? {
        val k = try {
            BuildConfig.GEMINI_API_KEY
        } catch (_: Exception) {
            ""
        }
        return k.trim().takeIf { it.isNotBlank() && it != "MY_GEMINI_API_KEY" && it != "null" }
    }

    /**
     * Returns the stored key list, creating it on first use. Migration order:
     * 1. the legacy single key (`gemini_api_key`) is moved into the list and removed,
     * 2. otherwise the build-time key (if any) seeds the list.
     */
    private fun loadKeys(context: Context): List<String> {
        keysCache?.let { return it }
        synchronized(keysLock) {
            keysCache?.let { return it }
            val prefs = getSecurePrefs(context)
            val raw = prefs.getString(KEY_API_KEYS_JSON, null)
            val keys: List<String> = if (raw != null) {
                parseKeys(raw)
            } else {
                val migrated = LinkedHashSet<String>()
                prefs.getString(KEY_API_KEY, "")?.trim()?.takeIf { it.isNotEmpty() }?.let { migrated.add(it) }
                if (migrated.isEmpty()) buildConfigKeyOrNull()?.let { migrated.add(it) }
                val list = migrated.toList()
                prefs.edit()
                    .putString(KEY_API_KEYS_JSON, serializeKeys(list))
                    .remove(KEY_API_KEY)
                    .putBoolean(KEY_SEEDED_INITIAL, true)
                    .apply()
                list
            }
            keysCache = keys
            return keys
        }
    }

    private fun parseKeys(raw: String): List<String> = try {
        val array = JSONArray(raw)
        val out = LinkedHashSet<String>()
        for (i in 0 until array.length()) {
            array.optString(i, "").trim().takeIf { it.isNotEmpty() }?.let { out.add(it) }
        }
        out.toList()
    } catch (_: Exception) {
        emptyList()
    }

    private fun serializeKeys(keys: List<String>): String {
        val array = JSONArray()
        keys.forEach { array.put(it) }
        return array.toString()
    }

    private fun persistKeys(context: Context, keys: List<String>) {
        getSecurePrefs(context).edit()
            .putString(KEY_API_KEYS_JSON, serializeKeys(keys))
            .putBoolean(KEY_SEEDED_INITIAL, true)
            .apply()
        keysCache = keys
    }

    /**
     * Usable Gemini API keys for rotation: every key that is not marked exhausted
     * (all keys when every one is exhausted, so a request can still be attempted).
     */
    fun getApiKeys(): List<String> {
        val ctx = appContext ?: return emptyList()
        ensureRepository(ctx)
        return ApiKeyRepository.getUsableKeyValues()
    }

    /** Adds [key] (trimmed) with the default model. Blank keys and duplicates are ignored. */
    fun addApiKey(key: String) {
        val ctx = appContext ?: return
        ensureRepository(ctx)
        ApiKeyRepository.add(key)
    }

    /** Removes [key] from the list (no-op if absent). */
    fun removeApiKey(key: String) {
        val ctx = appContext ?: return
        ensureRepository(ctx)
        ApiKeyRepository.deleteByKeyValue(key)
    }

    /**
     * Thread-safe round-robin: every call returns the next key in the list,
     * or null when no key is stored.
     */
    fun getNextApiKey(): String? {
        val keys = getApiKeys()
        if (keys.isEmpty()) return null
        val idx = Math.floorMod(rotationIndex.getAndIncrement(), keys.size)
        return keys[idx]
    }

    /** First stored key, or "" when none (kept for existing callers that only need "is a key set?"). */
    fun getApiKey(context: Context): String {
        if (appContext == null) appContext = context.applicationContext
        ensureRepository(context.applicationContext)
        return ApiKeyRepository.getUsableKeyValues().firstOrNull().orEmpty()
    }

    /** Backward-compatible single-key save: adds the key to the rotation list. */
    fun saveApiKey(context: Context, apiKey: String) {
        if (appContext == null) appContext = context.applicationContext
        addApiKey(apiKey)
    }

    fun getModelName(context: Context): String {
        val stored = getStandardPrefs(context).getString(KEY_MODEL_NAME, DEFAULT_MODEL_NAME)?.trim()
        return if (stored.isNullOrEmpty() || stored == "gemini-3.5-transcribe" || stored.startsWith("gemini-2.")) {
            DEFAULT_MODEL_NAME
        } else {
            stored
        }
    }

    fun saveModelName(context: Context, modelName: String) {
        val clean = modelName.trim().ifEmpty { DEFAULT_MODEL_NAME }
        getStandardPrefs(context).edit().putString(KEY_MODEL_NAME, clean).apply()
    }

    fun getSyncWithKeyboard(context: Context): Boolean {
        return getStandardPrefs(context).getBoolean(KEY_SYNC_KEYBOARD, false)
    }

    fun saveSyncWithKeyboard(context: Context, enabled: Boolean) {
        getStandardPrefs(context).edit().putBoolean(KEY_SYNC_KEYBOARD, enabled).apply()
        _syncKeyboardFlow.value = enabled
    }

    fun saveBubblePosition(context: Context, x: Int, y: Int) {
        getStandardPrefs(context).edit()
            .putInt(KEY_SAVED_X, x)
            .putInt(KEY_SAVED_Y, y)
            .apply()
    }

    fun getBubblePosition(context: Context, defaultX: Int = 0, defaultY: Int = 260): Pair<Int, Int> {
        val prefs = getStandardPrefs(context)
        val x = prefs.getInt(KEY_SAVED_X, defaultX)
        val y = prefs.getInt(KEY_SAVED_Y, defaultY)
        return x to y
    }

    fun addHistoryItem(context: Context, text: String, modelUsed: String) {
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return

        val current = loadHistory(context).toMutableList()
        val now = System.currentTimeMillis()
        current.add(
            0,
            TranscriptionRecord(
                id = now,
                text = trimmed,
                timestamp = now,
                modelUsed = modelUsed
            )
        )
        val capped = current.take(MAX_HISTORY_ITEMS)
        saveHistory(context, capped)
        _historyFlow.value = capped
    }

    fun clearHistory(context: Context) {
        getStandardPrefs(context).edit().remove(KEY_HISTORY_JSON).apply()
        _historyFlow.value = emptyList()
    }

    fun loadHistory(context: Context): List<TranscriptionRecord> {
        val raw = getStandardPrefs(context).getString(KEY_HISTORY_JSON, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = mutableListOf<TranscriptionRecord>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(
                    TranscriptionRecord(
                        id = obj.optLong("id", System.currentTimeMillis() + i),
                        text = obj.optString("text", ""),
                        timestamp = obj.optLong("timestamp", System.currentTimeMillis()),
                        modelUsed = obj.optString("modelUsed", DEFAULT_MODEL_NAME)
                    )
                )
            }
            result.filter { it.text.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun saveHistory(context: Context, list: List<TranscriptionRecord>) {
        val array = JSONArray()
        for (item in list) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("text", item.text)
                put("timestamp", item.timestamp)
                put("modelUsed", item.modelUsed)
            }
            array.put(obj)
        }
        getStandardPrefs(context).edit().putString(KEY_HISTORY_JSON, array.toString()).apply()
    }
}
